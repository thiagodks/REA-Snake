from pygame_functions2 import *
from pygame.locals import *
import pygame
import time
import Connect2Server as connect
import Game as g

class Login:
	
	def init(self):
		pygame.init()
		self.width = 600
		self.height = 400	
		
		self.cliente = connect.Cliente()

		screenSize(self.width,self.height)
		# self.dicUsers =  self.loadUsers()

		self.display_G = pygame.display.set_mode((self.width, self.height), pygame.HWSURFACE)
		pygame.display.set_caption('Login')
		self.background = pygame.image.load("icons/snakeLogin2.png").convert_alpha()
		self.btLogar = pygame.image.load("icons/buttons/entrar.png").convert_alpha()
		self.btCadastrar = pygame.image.load("icons/buttons/cadastrar.png").convert_alpha()

		self.display_G.fill((131,163,2))
		self.display_G.blit(self.background,(230, 20))
		self.display_G.blit(self.btLogar, (300-174,300)) # paint to screen
		self.display_G.blit(self.btCadastrar, (320,300))

		self.logarCoord = (300-174,300)
		self.cadastrarCoord = (320,300)
		
		lbID = makeLabel("Nome:", 35, 185-105, 187, "white", "Agency FB", (131,163,2))
		lbSenha = makeLabel("Senha:", 35, 185-105, 257, "white", "Agency FB", (131,163,2))

		tfID = makeTextBox(185, 180, 250, 0, "Ex: Pedro", 15, 24)
		tfSenha = makeTextBox(185, 250, 250, 0, "Costela", 15, 24)
		
		showLabel(lbID)
		showLabel(lbSenha)
		
		showTextBox(tfID)
		showTextBox(tfSenha)
		
		if not self.cliente.connectServer('localhost', 6790):
			self.connectionFail()
			print('Falha ao connecta no servidor')
			return

		LOGIN = CADASTRO = False
		self.nome = senha = ''

		while not LOGIN:

			pygame.event.pump()
			for event in pygame.event.get():
				if event.type == pygame.MOUSEBUTTONDOWN:
					
					x, y = event.pos
					if 185 <= x <= 185 + 250:
						if 180 <= y <= 180 + 40:
							self.nome, tp = textBoxInput(tfID)
							x, y = tp[0], tp[1]

					if 185 <= x <= 185 + 250:
						if 250 <= y <= 250 + 40:
							senha, tp = textBoxInput(tfSenha)
							x, y = tp[0], tp[1]

					if 185 <= x <= 185 + 250:
						if 180 <= y <= 180 + 40:
							self.nome, tp = textBoxInput(tfID)
							x, y = tp[0], tp[1]

					if self.logarCoord[0] <= x <= self.logarCoord[0] + 174:
						if self.logarCoord[1] <= y <= self.logarCoord[1] + 90:
							LOGIN = self.verifyLogin(self.nome, senha)
							if not LOGIN: self.LoginFail()

					if self.cadastrarCoord[0] <= x <= self.cadastrarCoord[0] + 174:
						if self.cadastrarCoord[1] <= y <= self.cadastrarCoord[1] + 90:
							CADASTRO = self.Register(self.nome, senha)
							if CADASTRO: 
								self.registerSucess()
							else: self.RegisterFail()

				if event.type == pygame.QUIT:
					return

		pygame.quit()
		game = g.GAME()
		game.init()
		game.initMenu(self.nome, self.cliente, False)
		# game.initGame()
		# game.playGame()
	
	def registerSucess(self):
		lbID = makeLabel("Cadastro efetuado com Sucesso :)", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)
		time.sleep(2)
		lbID = makeLabel("                                                                  ", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)

	def connectionFail(self):
		lbID = makeLabel("Falha ao conectar no Servidor :(", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)
		time.sleep(2)
		lbID = makeLabel("                                                               ", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)

	def LoginFail(self):
		lbID = makeLabel("Nome ou senha incorreta :(", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)
		time.sleep(2)
		lbID = makeLabel("                                                               ", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)

	def RegisterFail(self):
		lbID = makeLabel("Nome de usuário já cadastrado :(", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)
		time.sleep(2)
		lbID = makeLabel("                                                               ", 25, 10, self.height-20, "white", "Agency FB", (131,163,2))
		showLabel(lbID)

	def verifyLogin(self, nome, senha):

		return self.cliente.loginUser(nome, senha)


	def Register(self, nome, senha):

		return self.cliente.addUser(nome, senha)

if __name__ == "__main__":
	login = Login()
	login.init()
import Connect2Server as connect
from pygame_functions import *
from pygame.locals import *
from random import randint
import snake as s
import Drops as d
import pygame
import time

GAME_OVER = False
HEAD = 0

X = 1
Y = 2

RIGHT = 0
LEFT = 1
UP = 2
DOWN = 3

size = 32


class GAME:

	def init(self):
		pygame.init()
		pygame.mixer.init()
		pygame.mixer.music.load('sounds/heal.mp3')
		info = pygame.display.Info()
		
		self.width = info.current_w
		self.height = info.current_h

		# self.display_G = pygame.display.set_mode((self.width, self.height), pygame.HWSURFACE)
		self.display_G = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
		pygame.display.set_caption('Snake')
		self.logo = pygame.image.load("icons/logoSnake2.png").convert_alpha()
		self.sn1 = pygame.image.load("icons/intro_snake1.png").convert_alpha()
		self.sn2 = pygame.image.load("icons/intro_snake2.png").convert_alpha()
		self.background = pygame.image.load("icons/backIntro.png").convert()
		self.display_G.blit(self.background,(0, 0))

		pygame.display.flip()
		pygame.mixer.music.play()
		pygame.event.wait()

		aux = -512

		pygame.mouse.set_visible(False)

		while aux < self.width:

			self.display_G.fill(((0,0,0)))
			self.display_G.blit(self.logo,(int(self.width/2)-170, int(self.height/2)-125))
			pygame.display.update()

			self.display_G.blit(self.sn1,(aux, self.height-150))
			pygame.display.update()
			time.sleep(0.1)

			self.display_G.fill(((0,0,0)))
			self.display_G.blit(self.logo,(int(self.width/2)-170, int(self.height/2)-125))
			pygame.display.update()

			aux += 140
			self.display_G.blit(self.sn2,(aux, self.height-150))
			pygame.display.update()
			time.sleep(0.1)
		
			for event in pygame.event.get():
				if event.type == KEYDOWN:
					aux = self.width


	def showInfo(self):
		self.display_G.blit(self.backInfo, (self.width-356, 20)) # paint to screen
		self.display_G.blit(self.btClose, ((self.width)-55, 30)) # paint to screen
		pygame.display.flip()
		self.closeCoord = ((self.width-55, 30))
		while True:
			pygame.event.pump()
			for event in pygame.event.get():
				if event.type == pygame.MOUSEBUTTONDOWN:
					x, y = event.pos
					if self.closeCoord[0] <= x <= self.closeCoord[0] + 174:
						if self.closeCoord[1] <= y <= self.closeCoord[1] + 90:
							pygame.mixer.music.pause()
							self.initMenu(self.namePlayer, self.clientConnection, True)
							return

	def showRecords(self):
		self.display_G.blit(self.backRecords, (self.width-260, 20)) # paint to screen
		self.display_G.blit(self.btClose, ((self.width-260)+210, 30)) # paint to screen
		self.posY = [90, 130, 170, 210, 250, 290, 330, 370, 410, 450]
		pos = 0
		add = 0
		if len(self.TOP10) < 10: add = 10 - len(self.TOP10)
		for i in range(len(self.TOP10)-1, -1, -1):
			# lbUser = makeLabel(str(pos+1)+"										 ", 25, (self.width-260)+40, self.posY[pos], "red", "Agency FB", (59,64,42))
			# lbUser = makeLabel(str(pos+1)+"															 ", 25, (self.width-260)+40, self.posY[pos], "red", "Agency FB", (89, 89, 89))
			if self.namePlayer == self.TOP10[i][0]:
				lbUser = makeLabel(str(pos+1)+") "+self.TOP10[i][0]+": "+str(self.TOP10[i][1]), 25, (self.width-260)+40, self.posY[pos], "red", "Agency FB", (89, 89, 89))

			else: 
				# lbUser = makeLabel(str(pos+1)+"															 ", 25, (self.width-260)+40, self.posY[pos], "red", "Agency FB", (89, 89, 89))
				lbUser = makeLabel(str(pos+1)+") "+self.TOP10[i][0]+": "+str(self.TOP10[i][1]), 25, (self.width-260)+40, self.posY[pos], "white", "Agency FB", (89, 89, 89))
			showLabel(lbUser)
			pos += 1
			if i == 0:
				for j in range(0, add):
					# lbUser = makeLabel(str(pos+1)+ "														", 25, (self.width-260)+40, self.posY[pos], "white", "Agency FB", (89, 89, 89))
					lbUser = makeLabel(str(pos+1)+") - : -", 25, (self.width-260)+40, self.posY[pos], "white", "Agency FB", (89, 89, 89))
					showLabel(lbUser)
					pos += 1
				break

		clearLabels()
		# del lbUser
		self.closeCoord = ((self.width-260)+210, 30)
		while True:
			pygame.event.pump()
			for event in pygame.event.get():
				if event.type == pygame.MOUSEBUTTONDOWN:
					x, y = event.pos
					if self.closeCoord[0] <= x <= self.closeCoord[0] + 174:
						if self.closeCoord[1] <= y <= self.closeCoord[1] + 90:
							pygame.mixer.music.pause()
							self.initMenu(self.namePlayer, self.clientConnection, True)
							# return

	def initMenu(self, namePlayer, clientConnection, conti):
		pygame.init()
		self.conti = conti
		if not self.conti:
			pygame.mixer.init()
			pygame.mixer.music.load('sounds/menu.wav')
			pygame.mixer.music.play()
		else:
			pygame.mixer.music.unpause()

		info = pygame.display.Info()
		
		self.clientConnection = clientConnection
		self.namePlayer = namePlayer
		self.getTOP10()
		self.width = info.current_w
		self.height = info.current_h
		clearLabels()

		screenSize(self.width,self.height)
		self.display_G = pygame.display.set_mode((self.width, self.height), pygame.HWSURFACE)
		# self.display_G = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
		pygame.display.set_caption('Snake')
		self.background = pygame.image.load("icons/background3.jpg").convert()
		self.background = pygame.transform.scale(self.background, (self.width, self.height))
		
		self.backRecords = pygame.image.load("icons/backRecords.png").convert_alpha()
		self.cobraMat = pygame.image.load("icons/title.png").convert_alpha()
		self.credits = pygame.image.load("icons/credits.png").convert_alpha()
		self.backInfo = pygame.image.load("icons/backInfo.png").convert_alpha()

		self.btClose = pygame.image.load("icons/close.png").convert_alpha()
		self.btPlay = pygame.image.load("icons/buttons/jogar.png").convert_alpha()
		self.btRecords = pygame.image.load("icons/buttons/recordes.png").convert_alpha()
		self.btInfo = pygame.image.load("icons/buttons/info.png").convert_alpha()
		self.btSair = pygame.image.load("icons/buttons/sair.png").convert_alpha()
		self.btContinuar = pygame.image.load("icons/buttons/continuar.png").convert_alpha()
		self.display_G.blit(self.background,(0, 0))
		pygame.display.update()

		espaco = 20
		btwidth = 174
		bt1 = int((self.width-(3*espaco)-(4*btwidth))/2)
		cy = int(self.height-100)-45

		self.display_G.blit(self.cobraMat, ((self.width/2)-160, (self.height/2)-200)) # paint to screen
		self.display_G.blit(self.credits, ((self.width/2)-325, (self.height/2)+100)) # paint to screen
		self.display_G.blit(self.btPlay, (bt1, cy)) # paint to screen
		self.display_G.blit(self.btRecords, (bt1 + espaco + btwidth, cy)) # paint to screen
		self.display_G.blit(self.btInfo, (bt1 + (2 * (espaco + btwidth)), cy)) # paint to screen
		self.display_G.blit(self.btSair, (bt1 + (3 * (espaco + btwidth)), cy)) # paint to screen
		pygame.display.update()

		self.playCoord = (bt1, cy)
		self.recordsCoord = (bt1 + espaco + btwidth, cy)
		self.infoCoord = (bt1 + (2 * (espaco + btwidth)), cy)
		self.sairCoord = (bt1 + (3 * (espaco + btwidth)), cy)

		pygame.display.flip()
		MUSIC_END = pygame.USEREVENT+1
		pygame.mixer.music.set_endevent(MUSIC_END)

		loopMenu = True

		pygame.mouse.set_visible(True)

		while loopMenu:
			pygame.event.pump()
			keys = pygame.key.get_pressed() 
			if (keys[K_ESCAPE]): break
			# if pygame.mixer.music.get_endevent(): pygame.mixer.music.play()
			for event in pygame.event.get():
				if event.type == MUSIC_END: pygame.mixer.music.play()
				if event.type == pygame.QUIT: loopMenu = False
				if event.type == pygame.MOUSEBUTTONDOWN:
					x, y = event.pos
					if self.playCoord[0] <= x <= self.playCoord[0] + 174:
						if self.playCoord[1] <= y <= self.playCoord[1] + 90:
							pygame.mixer.music.stop()	
							self.initGame()
							self.playGame()

					elif self.sairCoord[0] <= x <= self.sairCoord[0] + 174:
						if self.sairCoord[1] <= y <= self.sairCoord[1] + 90:
							exit(0)
					
					elif self.recordsCoord[0] <= x <= self.recordsCoord[0] + 174:
						if self.recordsCoord[1] <= y <= self.recordsCoord[1] + 90:
							self.showRecords()

					elif self.infoCoord[0] <= x <= self.infoCoord[0] + 174:
						if self.infoCoord[1] <= y <= self.infoCoord[1] + 90:
							self.showInfo()

	def initGame(self):
		pygame.init()
		self.info = pygame.display.Info()
		
		self.width = self.info.current_w
		self.height = self.info.current_h

		self.N = int(self.width/size)
		self.M = int(self.height/size)

		self.width = size * self.N;
		self.height = size * self.M;

		self.display_G = pygame.display.set_mode((self.info.current_w, self.info.current_h), pygame.HWSURFACE)
		# self.display_G = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

		self.background1 = pygame.image.load("icons/background1.jpg").convert()
		self.background2 = pygame.image.load("icons/logoSnake2.png").convert_alpha()
		self.background1 = pygame.transform.scale(self.background1, (self.info.current_w, self.info.current_h))
		
		self.snake = s.Snake(1, self.width, self.height, self.N, self.M)
		self.drop = d.Drops(self.width, self.height, self.N, self.M)
		self.exp1, self.exp2, self.exp3, self.exp4, self.exp5 = 0,0,0,0,0

		self.currentDrop = self.drop.generateNumber()
		self.NUM1 = self.currentDrop[3]
		self.pontos = 0
		self.typeDrop = 'Number1'

		pygame.display.set_caption('Snake')

	def drawCountDown(self):
		for i in range(3, 0, -1):
			self.imgCountD = pygame.image.load("icons/num"+str(i)+".png").convert_alpha()
			self.display_G.blit(self.background1,(0, 0))
			self.display_G.blit(self.imgCountD,((self.info.current_w/2)-54, (self.info.current_h/2)-101))
			pygame.display.flip()
			time.sleep(1)
			self.display_G.fill((0,0,0))

	def rmExpScreen(self):
		self.exp1 = self.exp2 = self.exp3 = self.exp4 = self.exp5 = 0

	def drawExpression(self, img):
		x = int(self.N/2)
		# (15,1) (16,1) (17,1) (18,1) (19, 1)
		if self.typeDrop == 'Number1':
			self.exp1 = (img, x-4, self.M-3) 
		if self.typeDrop == 'Operator':
			self.exp2 = (img, x-2, self.M-3)
		if self.typeDrop == 'Number2':
			self.exp3 = (img, x, self.M-3)
			self.exp4 = (self.drop.imgEquals, x+2, self.M-3)

	def drawGAME(self):
		if self.countDown:
			self.drawCountDown()
			self.countDown = False
		else: 
			self.display_G.fill((0,0,0))
			self.display_G.blit(self.background1,(0, 0))
			self.snake.draw(self.display_G)
			if self.typeDrop != 'Answers': self.drop.draw(self.display_G, self.currentDrop)
			else: self.drop.drawAnswers(self.display_G, self.Answers)

			self.display_G.blit(self.play_pause,(5, self.height-70))
			self.display_G.blit(self.score,(self.width-100, 20))
			self.drop.drawScore(self.display_G, self.pontos)
			if self.exp1 != 0: 
				self.drop.draw2(self.display_G, (self.backOp, self.exp1[1]*size-10, self.exp1[2]*size-10))
				self.drop.draw(self.display_G, self.exp1)
			if self.exp2 != 0: self.drop.draw(self.display_G, self.exp2)
			if self.exp3 != 0: self.drop.draw(self.display_G, self.exp3)
			if self.exp4 != 0: self.drop.draw(self.display_G, self.exp4)
			if self.exp5 != 0:
				self.drop.draw(self.display_G, self.exp5)
				pygame.display.flip()
				time.sleep(0.1)
				self.rmExpScreen()

			pygame.display.flip()

	def drawANIMATION(self):
		self.display_G.fill((0,0,0))
		self.display_G.blit(self.background1,(0, 0))
		self.snake.draw(self.display_G)
		self.drop.drawAnswers(self.display_G, self.Answers)

		self.display_G.blit(self.play_pause,(5, self.height-70))
		self.display_G.blit(self.score,(self.width-100, 20))
		self.drop.drawScore(self.display_G, self.pontos)
		if self.exp1 != 0: 
			self.drop.draw2(self.display_G, (self.backOp, self.exp1[1]*size-10, self.exp1[2]*size-10))
			self.drop.draw(self.display_G, self.exp1)
		if self.exp2 != 0: self.drop.draw(self.display_G, self.exp2)
		if self.exp3 != 0: self.drop.draw(self.display_G, self.exp3)
		if self.exp4 != 0: self.drop.draw(self.display_G, self.exp4)
		if self.exp5 != 0:
			self.drop.draw(self.display_G, self.exp5)
			pygame.display.flip()
			time.sleep(0.1)
			self.rmExpScreen()

		pygame.display.flip()

	def isCollision(self, headSnake, currentDrop):

		if headSnake[X] == currentDrop[X] and headSnake[Y] == currentDrop[Y]:
			return True

		return False

	def getAnswer(self, num):
		for i in self.Answers:
			if i[3] == num: return i

	def checkCollisions(self):
		
		for i in range(2,len(self.snake.body)):
			if self.isCollision(self.snake.body[HEAD], self.snake.body[i]):
				if self.dicUsers[self.namePlayer] < self.pontos:
					# del self.dicUsers[self.namePlayer]
					# self.dicUsers[self.namePlayer] = self.pontos
					print("OK? ",self.clientConnection.updateRecord(self.namePlayer, self.pontos))
					self.getTOP10()

				self.display_G.blit(self.gameOver,((self.info.current_w/2)-147, (self.info.current_h/2)-84))
				pygame.display.flip()
				time.sleep(3)
				self.initMenu(self.namePlayer, self.clientConnection, False)

		if self.typeDrop == 'Answers':
			for answers in self.Answers:
				if self.isCollision(self.snake.body[HEAD], answers):
					self.typeDrop = 'Number1'
					self.exp5 = (self.getAnswer(self.resp)[0], int(self.N/2)+4, self.M-3)
					if answers[3] == self.resp:
						self.playRightAnswAnimation()
						self.pontos = self.pontos + 3
					else: 
						self.drop.drawCorrectAnswer(self.display_G, self.getAnswer(self.resp))
						self.playWrongAnswAnimation()
						self.pontos = self.pontos - 3
					
					self.currentDrop = self.drop.generateNumber()
					self.NUM1 = self.currentDrop[3]

		elif self.isCollision(self.snake.body[HEAD], self.currentDrop):
			self.drawExpression(self.currentDrop[0])
			lastPosition = len(self.snake.body)-2
			self.snake.body[len(self.snake.body) -1] = ([self.currentDrop[0], self.snake.body[lastPosition][X], self.snake.body[lastPosition][Y], self.snake.body[len(self.snake.body) -1][4], self.snake.body[len(self.snake.body) -1][3], False])
			lastPosition = len(self.snake.body)-1
			self.snake.body.append([self.snake.imgTail, self.snake.body[lastPosition][X], self.snake.body[lastPosition][Y], self.snake.body[len(self.snake.body) -1][4], self.snake.body[len(self.snake.body) -1][4], False])
			
			# self.snake.TAIL = False
			if self.typeDrop == 'Number1':
				self.currentDrop = self.drop.generateOperator()
				self.OP = self.currentDrop[3]
				self.typeDrop = 'Operator'
			
			elif self.typeDrop == 'Operator':
				self.currentDrop = self.drop.generateNumber()
				self.NUM2 = self.currentDrop[3]	
				self.typeDrop = 'Number2'
			
			elif self.typeDrop == 'Number2':
				# GERAR VARIOS NUMEROS CM A RESPOSTA DA OPERAÇÃO FEITA
				if self.OP == 'sum.png': 
					self.Answers = self.drop.generateDN(self.NUM1+self.NUM2, 5)	
					self.resp = self.NUM1+self.NUM2
				elif self.OP == 'sub.png':
					self.Answers = self.drop.generateDN(self.NUM1-self.NUM2, 5)	
					self.resp = self.NUM1-self.NUM2
				elif self.OP == 'mul.png': 
					self.Answers = self.drop.generateDN(self.NUM1*self.NUM2, 5)	
					self.resp = self.NUM1*self.NUM2
				else: 
					self.Answers = self.drop.generateDN(self.NUM1/self.NUM2, 5)	
					self.resp = self.NUM1/self.NUM2
				# self.currentDrop = self.drop.generateDN(self.display_G, randint(2, 5))	
				self.typeDrop = "Answers"


		self.snake.update()

	def playWrongAnswAnimation(self):
		for i in range(3):
			for sprite in self.snake.wrongAnswAnimation:
				self.snake.body[len(self.snake.body)-2][0] = sprite
				time.sleep(0.02)
				self.drawANIMATION()
			self.snake.body.pop(len(self.snake.body)-2)

	def playRightAnswAnimation(self):

		for sprite in self.snake.rightAnswAnimation:
			self.snake.body[len(self.snake.body)-2][0] = sprite
			self.snake.body[len(self.snake.body)-3][0] = sprite
			self.snake.body[len(self.snake.body)-4][0] = sprite
			time.sleep(0.08)
			self.drawANIMATION()

		self.snake.body.pop(len(self.snake.body)-2)
		self.snake.body.pop(len(self.snake.body)-2)
		self.snake.body[len(self.snake.body)-2][0] = self.snake.imgBody
		self.snake.body[len(self.snake.body)-2][5] = True
	
	def pauseGame(self):
		pygame.mouse.set_visible(True)
		self.display_G.blit(self.backPause, ((self.info.current_w/2)-240, (self.info.current_h/2)-240)) # paint to screen
		self.display_G.blit(self.btContinuar, ((self.info.current_w/2)-87, (self.info.current_h/2)-100+30))
		self.display_G.blit(self.btSair, ((self.info.current_w/2)-87, (self.info.current_h/2)+10+30))
		pygame.display.flip()
		while True:
			for event in pygame.event.get():
				keys = pygame.key.get_pressed()
				if keys[K_p]:
					return
				if event.type == pygame.MOUSEBUTTONDOWN:
					x, y = event.pos

					if self.contCoord[0] <= x <= self.contCoord[0] + 174:
						if self.contCoord[1] <= y <= self.contCoord[1] + 90:
							return
					if self.sairCoord[0] <= x <= self.sairCoord[0] + 174:
						if self.sairCoord[1] <= y <= self.sairCoord[1] + 90:
							self.initMenu(self.namePlayer, self.clientConnection, False)
	def playGame(self):

		pygame.mouse.set_visible(False)

		pygame.mixer.init()
		track = 1
		pygame.mixer.music.load('sounds/gameSounds/track'+str(track)+'.mp3')
		MUSIC_END = pygame.USEREVENT+1
		pygame.mixer.music.set_endevent(MUSIC_END)

		self.play_pause = pygame.image.load("icons/playMusic.png").convert_alpha()
		self.score = pygame.image.load("icons/score_board.png").convert_alpha()
		self.backPause = pygame.image.load("icons/backPause.png").convert_alpha()
		self.backOp = pygame.image.load("icons/backOp.png").convert_alpha()
		self.btSair = pygame.image.load("icons/buttons/sair.png").convert_alpha()
		self.btContinuar = pygame.image.load("icons/buttons/continuar.png").convert_alpha()
		self.gameOver = pygame.image.load("icons/gameOver.png").convert_alpha()

		self.contCoord = ((self.info.current_w/2)-87, (self.info.current_h/2)-100+30)
		self.sairCoord = ((self.info.current_w/2)-87, (self.info.current_h/2)+10+30)
		self.ppCoord = (5, self.height-67)
		pp = True
		self.countDown = True
		self.drawGAME()
		pygame.mixer.music.play()
		self.pause = False

		while not GAME_OVER:
			pygame.event.pump()
			keys = pygame.key.get_pressed()
			for event in pygame.event.get():

				if event.type == MUSIC_END:
					track += 1
					if track == 4: track = 1
					pygame.mixer.music.load('sounds/gameSounds/track'+str(track)+'.mp3')
					pygame.mixer.music.play()

				elif event.type == pygame.MOUSEBUTTONDOWN:
					x, y = event.pos
					if self.ppCoord[0] <= x <= self.ppCoord[0] + 67:
						if self.ppCoord[1] <= y <= self.ppCoord[1] + 67:
							if pp: 
								self.play_pause = pygame.image.load("icons/pauseMusic.png").convert_alpha()
								pygame.mixer.music.stop()
								pp = False
							else: 
								self.play_pause = pygame.image.load("icons/playMusic.png").convert_alpha()
								pygame.mixer.music.play()
								pp = True

			if keys[K_m]:
				if pp:
					self.play_pause = pygame.image.load("icons/pauseMusic.png").convert_alpha()
					pygame.mixer.music.stop()
					pp = False
				else:
					self.play_pause = pygame.image.load("icons/playMusic.png").convert_alpha()
					pygame.mixer.music.play()
					pp = True
				time.sleep(0.05)

			if (keys[K_RIGHT] or keys[K_d]):
				self.snake.moveRight()

			if (keys[K_LEFT] or keys[K_a]):
				self.snake.moveLeft()

			if (keys[K_UP] or keys[K_w]):
				self.snake.moveUp()

			if (keys[K_DOWN] or keys[K_s]):
				self.snake.moveDown()

			# if (keys[K_ESCAPE]):
				# break
				
			if keys[K_p]:
				self.pauseGame()
				time.sleep(0.5)
				pygame.mouse.set_visible(False)
		
			self.checkCollisions()
			self.drawGAME()
			time.sleep (0.065);

		pygame.quit()

	def sortDic(self):
		sorted_x = []
		sorted_x.clear()
		sorted_x = sorted(self.dicUsers.items(), key=lambda kv: kv[1])
		return sorted_x

	def getTOP10(self):
		self.dicUsers = {}
		self.dicUsers.clear()
		self.dicUsers = self.clientConnection.getRecords()
		self.TOP10 = []
		self.TOP10.clear()
		self.TOP10 = self.sortDic()
		if len(self.TOP10) > 10:
			x = len(self.TOP10) - 10
			self.TOP10 = self.TOP10[x:]



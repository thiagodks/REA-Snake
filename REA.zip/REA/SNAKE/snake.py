from pygame.locals import *
from random import randint
import pygame
import time
HEAD = 0

RIGHT = 0
LEFT = 1
UP = 2
DOWN = 3

IMG = 0
X = 1
Y = 2
PREV_DIR = 3
CUR_DIR = 4
size = 32

class Snake:

	def __init__(self, speed, windowWidth, windowHeight, N, M):
		self.N = N-1
		self.M = M-1
		self.speed = speed
		self.direction = RIGHT
		self.windowWidth = windowWidth
		self.windowHeight = windowHeight
		self.imgHead = pygame.image.load("icons/Snake/head_r.png").convert_alpha()
		self.imgTail = pygame.image.load("icons/Snake/tail_r.png").convert_alpha()
		self.imgBody = pygame.image.load("icons/Snake/body_r.png").convert_alpha()
		self.wrongAnswAnimation = []
		self.rightAnswAnimation = []
		self.loadAnswerAnimation()


		self.body = []
		self.body.append([self.imgHead, 0, 0, RIGHT, RIGHT, False]) # x, y
		self.body.append([self.imgTail, 0, 0, RIGHT, RIGHT, False]) # x, Y
		self.TAIL = True

	def loadAnswerAnimation(self):
		for i in range(1, 14):
			self.wrongAnswAnimation.append(
				pygame.image.load("icons/Snake/wrong_answer_animation/body_wrong_answer"+str(i)+".png").convert_alpha()
			)
			self.rightAnswAnimation.append(
				pygame.image.load("icons/Snake/right_answer_animation/body_right_answer"+str(i)+".png").convert_alpha()
			)

	def update(self):
		
		for i in range(len(self.body)-1, 0, -1):
			self.body[i][PREV_DIR] = self.body[i][CUR_DIR]
			self.body[i][CUR_DIR] = self.body[i-1][CUR_DIR]
			self.body[i][X], self.body[i][Y] = self.body[i-1][X], self.body[i-1][Y]
			if self.body[i][CUR_DIR] == RIGHT and self.body[i][5]:
				self.body[i][IMG] = self.imgBody = pygame.image.load("icons/Snake/body_r.png").convert_alpha()
			elif self.body[i][CUR_DIR] == LEFT and self.body[i][5]:
				self.body[i][IMG] = self.imgBody = pygame.image.load("icons/Snake/body_l.png").convert_alpha()
			elif self.body[i][CUR_DIR] == DOWN and self.body[i][5]:
				self.body[i][IMG] = self.imgBody = pygame.image.load("icons/Snake/body_d.png").convert_alpha()
			elif self.body[i][CUR_DIR] == UP and self.body[i][5]:
				self.body[i][IMG] = self.imgBody = pygame.image.load("icons/Snake/body_u.png").convert_alpha()

		if self.direction == RIGHT:
			self.body[HEAD][PREV_DIR] = self.body[HEAD][CUR_DIR]
			self.body[HEAD][CUR_DIR] = RIGHT
			if self.body[HEAD][X] >= self.N: self.body[HEAD][X] = 0
			else: self.body[HEAD][X] = self.body[HEAD][X] + self.speed
			self.imgHead = pygame.image.load("icons/Snake/head_r.png").convert_alpha()
			
		
		if self.direction == LEFT:
			self.body[HEAD][PREV_DIR] = self.body[HEAD][CUR_DIR]
			self.body[HEAD][CUR_DIR] = LEFT
			if self.body[HEAD][X] <= 0: self.body[HEAD][X] = self.N
			else: self.body[HEAD][X] = self.body[HEAD][X] - self.speed
			self.imgHead = pygame.image.load("icons/Snake/head_l.png").convert_alpha()
			
		
		if self.direction == UP:
			self.body[HEAD][PREV_DIR] = self.body[HEAD][CUR_DIR]
			self.body[HEAD][CUR_DIR] = UP
			if self.body[HEAD][Y] <= 0: self.body[HEAD][Y] = self.M
			else: self.body[HEAD][Y] = self.body[HEAD][Y] - self.speed
			self.imgHead = pygame.image.load("icons/Snake/head_u.png").convert_alpha()
			
		
		if self.direction == DOWN:
			self.body[HEAD][PREV_DIR] = self.body[HEAD][CUR_DIR]
			self.body[HEAD][CUR_DIR] = DOWN
			if self.body[HEAD][Y] >= self.M: self.body[HEAD][Y] = 0;
			else: self.body[HEAD][Y] = self.body[HEAD][Y] + self.speed
			self.imgHead = pygame.image.load("icons/Snake/head_d.png").convert_alpha()
			

		if self.body[len(self.body)-1][CUR_DIR] == LEFT: self.imgTail = pygame.image.load("icons/Snake/tail_l.png").convert_alpha()
		elif self.body[len(self.body)-1][CUR_DIR] == RIGHT: self.imgTail = pygame.image.load("icons/Snake/tail_r.png").convert_alpha()
		elif self.body[len(self.body)-1][CUR_DIR] == UP: self.imgTail = pygame.image.load("icons/Snake/tail_u.png").convert_alpha()
		else: self.imgTail = pygame.image.load("icons/Snake/tail_d.png").convert_alpha()

		self.body[HEAD][IMG] = self.imgHead
		self.body[len(self.body)-1][IMG] = self.imgTail
		


	def moveRight(self):
		if self.direction != LEFT:
			self.direction = RIGHT
 
	def moveLeft(self):
		if self.direction != RIGHT:
			self.direction = LEFT
 
	def moveUp(self):
		if self.direction != DOWN:
			self.direction = UP
 
	def moveDown(self):
		if self.direction != UP:
			self.direction = DOWN

	def draw(self, display_G):

		for i in range(0, len(self.body)):
			display_G.blit(self.body[i][IMG],(self.body[i][X]*size, self.body[i][Y]*size))

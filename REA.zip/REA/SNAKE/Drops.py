from pygame.locals import *
from random import randint
import pygame
import time

#laranja, azul, rosa, marrom, verde
CORES = ['l', 'a', 'r', 'm', 'v']
# OPERATORS = ['sum.png', 'sub.png', 'div.png', 'mul.png']
OPERATORS = ['sum.png', 'sub.png', 'mul.png']
# COORD_ANS = [(100, 100), (300, 300), (500, 300), (700, 500), (900, 100), (900, 200), (700, 400), (800, 400), (300, 500), (700, 100)]
RGB = [(0, 0, 255), (255, 51, 0), (255, 204, 0), (255, 51, 204), (102, 102, 51), (153, 0, 153), (153, 51, 51)]

size = 32

class Drops:
 
	def __init__(self, windowWidth, windowHeight, N, M):
		self.N = N-4
		self.M = M-4
		self.windowWidth = windowWidth
		self.windowHeight = windowHeight
		self.imgNumber = None
		self.imgOperator = None
		self.imgEquals = pygame.image.load('icons/equals.png').convert_alpha()
		self.imgSphere = pygame.image.load('icons/answer_sphere.png').convert_alpha()
		self.number = ()
		self.operator = ()
		self.move = -2

	def getNameImg(self, drop, num):
		cor = randint(0, 4)
		image = 'icons/'+drop+'/'+str(num)+str(CORES[cor])+'.png'
		return image

	def generateNumber(self):
		ax = int(self.N/2)
		while True:
			self.x = randint(0, self.N)
			self.y = randint(0, self.M)
			if self.x == ax or self.x == ax-2 or self.x == ax-4 or self.x == ax-6 or self.x == ax+2 or self.x == ax+4 or self.x != ax+6:
				if self.y == self.M-3 or self.y == self.M-4 or self.y == self.M-2: continue
				else: break
			else: break
				
		num = randint(0, 9)
		self.imgNumber = pygame.image.load(self.getNameImg('Numeros', num)).convert_alpha()
		self.number = (self.imgNumber, self.x, self.y, num)
		return self.number

	def generateOperator(self):
		op = randint(0, 2)
		self.imgOperator = pygame.image.load('icons/Operators/'+OPERATORS[op]).convert_alpha()
		self.x = randint(0, self.N)
		self.y = randint(0, self.M)
		self.operator = (self.imgOperator, self.x, self.y, OPERATORS[op])
		return self.operator

	def generateCoord(self, n):
		coord = []
		for i in range(0, n):
			while True:
				(x, y) = (randint(0, self.N), randint(0, self.M))
				if (x,y) not in coord:
					coord.append((x,y))
					break

		return coord


	def generateDN(self, resp, n):
		dNumbers = []
		coord = self.generateCoord(n)
		myfont = pygame.font.SysFont("comicsansms", 50)
		answers	= []
		for i in range(0, n-1):
			while True: 
				num = randint(1, int(resp)+10)
				if num != resp: break
			result = myfont.render(str(num), 1, RGB[i])
			answers.append((result, coord[i][0], coord[i][1], num))


		result = myfont.render(str(resp), 1, RGB[randint(0, 6)])
		answers.append((result, coord[n-1][0], coord[n-1][1], resp))
		
		return answers

	def drawAnswers(self, display_G, answers):
		
		for answer in answers:
			display_G.blit(answer[0], (answer[1]*size, answer[2]*size))
			if self.move == 2: self.move = -2
			else: self.move = 2 


	def draw(self, display_G, Drop):
		display_G.blit(Drop[0], (Drop[1]*size, Drop[2]*size)) 
		if self.move == 2: self.move = -2
		else: self.move = 2 
	
	def draw2(self, display_G, Drop):
			display_G.blit(Drop[0], (Drop[1], Drop[2])) 
			if self.move == 2: self.move = -2
			else: self.move = 2 

	def drawCorrectAnswer(self, display_G, Drop):
		resp = Drop[3]
		BW = [(0,0,0), (255,255,255)]
		myfont = pygame.font.SysFont("comicsansms", 50)
		for i in range(0, 10):
			if i % 2 == 0:
				result = myfont.render(str(resp), 1, (0,0,0))
			else:
				result = myfont.render(str(resp), 1, (255,255,255))
			display_G.blit(result, (Drop[1]*size, Drop[2]*size))
			pygame.display.flip()
			time.sleep (0.1);

		display_G.blit(result, (-1000, -1000))
		pygame.display.flip()


	def drawScore(self, display_G, score):

		sc = str(score)
		myfont = pygame.font.SysFont("comicsansms", 38)

		if (score > 9 or score < -9) and score < 100:
			if score < -9:
				s1, s2, = sc[0:2], sc[2]
			else: s1, s2 = sc[0], sc[1]
			r1 = myfont.render(str(s1), 1, (255,255,255))
			r2 = myfont.render(str(s2), 1, (255,255,255))
			display_G.blit(r1, (self.windowWidth-61, 25))
			display_G.blit(r2, (self.windowWidth-29, 25))
		elif score >= 100:
			s1, s2, s3 = sc[0], sc[1], sc[2]
			r0 = myfont.render(str(s1), 1, (255,255,255))
			r1 = myfont.render(str(s2), 1, (255,255,255))
			r2 = myfont.render(str(s3), 1, (255,255,255))
			display_G.blit(r0, (self.windowWidth-89, 25))
			display_G.blit(r1, (self.windowWidth-59, 25))
			display_G.blit(r2, (self.windowWidth-29, 25))

		else:
			r1 = myfont.render(sc, 1, (255,255,255))
			if score < 0: display_G.blit(r1, (self.windowWidth-31, 25))
			else: display_G.blit(r1, (self.windowWidth-29, 25))
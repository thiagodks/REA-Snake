from cx_Freeze import setup, Executable

executables = [Executable("Login.py"),
 Executable("Game.py"),
  Executable("Connect2Server.py"),
   Executable("Drops.py"),
    Executable("snake.py"),
     Executable("pygame_functions.py"),
      Executable("pygame_functions2.py")]

setup(name='SNAAKEE',
	version='1.0',
	description='REA IHC',
	options={'build_exe': {'packages': ['matplotlib']}},
	executables = executables
)
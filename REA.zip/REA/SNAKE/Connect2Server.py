#!/usr/bin/env python

import socket

class Cliente:

	def connectServer(self, IP, PORT):
		self.HOST = IP
		self.PORT = PORT
		try:
			self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self.sock.connect((self.HOST, self.PORT))
			return True
		except:
			return False

	def addUser(self, nome, senha):

		send = 'addUser '+nome+' '+senha+'\n'
		self.sock.sendall(send.encode())
		received = str(self.sock.recv(1024))
		if received.find('True') != -1:
			return True
		return False

	def loginUser(self, nome, senha):
		send = 'login '+nome+' '+senha+'\n'
		self.sock.sendall(send.encode())
		received = str(self.sock.recv(1024))
		if received.find('True') != -1:
			return True
		return False

	def getRecords(self):
		dicUsers = {}
		send = 'records'+'\n'
		self.sock.sendall(send.encode())
		received = str(self.sock.recv(7192))
		try:
			received = received[2:len(received)-5]
			received = received.split('::')
			for rc in received:
				nome, record = rc.split('|')[0], rc.split('|')[1]
				dicUsers[nome] = int(record)
		except: pass
		return dicUsers

	def updateRecord(self, nome, record):
		send = 'updateREC '+ nome+' '+str(record)+'\n'
		self.sock.sendall(send.encode())
		received = str(self.sock.recv(1024))
		return True

	def close(self):
		self.sock.close()
